import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

public class jT1 {
	
	 WebDriver d;
	  @Test(priority = 1)
	  public void UserReg() throws InterruptedException  {
		  System.setProperty("webdriver.chrome.driver", "D:\\TET (madhav)\\java\\chromedriver_win32\\chromedriver.exe");
	         d=new ChromeDriver();
			String url="https://jt-dev.azurewebsites.net/#/SignUp";
			d.get(url);
			d.manage().window().maximize();
			Thread.sleep(6000);
			WebElement w=d.findElement(By.xpath("//body/div[1]/div[2]/section[1]/div[1]/div[2]/section[1]/div[1]/div[1]/span[1]/span[2]"));
			w.click();
			//validate dropdown
			String eng=d.findElement(By.xpath("//div[contains(text(),'English')]")).getText();
			Assert.assertEquals(eng, "English");
			Thread.sleep(3000);
			String D=d.findElement(By.xpath("//div[contains(text(),'Dutch')]")).getText();
			Assert.assertEquals(D, "Dutch");
			Thread.sleep(2000);
	
			//fill name
			d.findElement(By.xpath("//input[@id='name']")).sendKeys("Mayuri Gosavi");
			Thread.sleep(3000);
			//org name
			d.findElement(By.xpath("//input[@id='orgName']")).sendKeys("xyz");
			Thread.sleep(3000);
			//enter mailid
			d.findElement(By.xpath("//input[@id='singUpEmail']")).sendKeys("madhavsutar06@gmail.com");
			Thread.sleep(2000);
			//chk box
			d.findElement(By.xpath("//span[contains(text(),'I agree to the')]")).click();
			Thread.sleep(2000);
			//get started 
			d.findElement(By.xpath("//button[contains(text(),'Get Started')]")).click();
			Thread.sleep(3000);
	  }
			
			//d.navigate().to("https://mail.google.com");
			//d.manage().window().maximize();
		//	d.findElement(By.xpath("//input[@id='identifierId']")).sendKeys("madhav.sutar.in");
		//	Thread.sleep(2000);
		//	d.findElement(By.xpath("//span[contains(text(),'Next')]")).click();
		//	Thread.sleep(3000);
		//	d.findElement(By.xpath("//body/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/form[1]/span[1]/section[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/input[1]")).sendKeys("@");
		//	Thread.sleep(3000);
		//	d.findElement(By.xpath("//span[contains(text(),'Next')]")).click();
			
		
			
			//@FindBy(how=How.XPATH, xpath="//span[@class='bog']")
			//List<WebElement> emailThreads;
			
		//	@FindBy(how=How.XPATH, xpath="//span[@class='gb_bb gbii']")
		//	WebElement profileLogo;
			
			
			@Test(priority=2)
			
				
			
			public void enterEmail() throws InterruptedException
			{
				d.navigate().to("https://mail.google.com");
				Thread.sleep(3000);
				WebElement emailField=d.findElement(By.xpath("//input[@id='identifierId']"));
				//WebElement emailField1=d.findElement(By.xpath("//input[contains(@class,'whsOnd zHQkBf')]"));
				waitForVisible1(d, emailField);
				Actions actions=new Actions(d);
				actions.moveToElement(emailField);
				actions.click();
				//enter maild id 
				actions.sendKeys("madhavsutar06@gmail.com");
				actions.build().perform();
				d.findElement(By.xpath("//span[contains(text(),'Next')]")).click();
				System.out.println("Email entered");
				Thread.sleep(3000);
				d.findElement(By.className("VfPpkd-vQzf8d")).click();//try again
				Thread.sleep(3000);
				d.findElement(By.xpath("/html/body/header/div/div/div/a[2]")).click(); 
				Thread.sleep(5000);
				
				//waitForVisible(d, emailField1);
				//Actions actions1=new Actions(d);
				//actions1.moveToElement(emailField1);
				//actions1.click();
				//actions1.sendKeys("madhavsutar06@gmail.com");
				//actions1.build().perform();
				//d.findElement(By.xpath("//span[contains(text(),'Next')]")).click();
				//System.out.println("Email entered");
				WebElement emailField11=d.findElement(By.xpath("//input[contains(@class,'whsOnd zHQkBf')]"));emailField11.sendKeys("madhavsutar06@gmail.com");
				Thread.sleep(2000);
				d.findElement(By.className("VfPpkd-vQzf8d")).click();
				Thread.sleep(3000);
				
				
			}
			
			private void waitForVisible1(WebDriver d, WebElement emailField) {
				// TODO Auto-generated method stub
				
			}
			@Test(priority=3)
			public void enterPassword()
			{
				WebElement passwordField=d.findElement(By.xpath("//body/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/form[1]/span[1]/section[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/input[1]"));
				  
			
				
				waitForVisible1(d, passwordField);
				Actions actions=new Actions(d);
				actions.moveToElement(passwordField);
				actions.click();
				actions.sendKeys("14v");
				actions.build().perform();
				d.findElement(By.xpath("//span[contains(text(),'Next')]")).click();
				System.out.println("Password entered");
			}

			//@Test(priority=4)
			//public void waitForVisible() {
			//	try {
			//String j=d.findElement(By.name("JabaTalks Developme.")).getText();
				//	Thread.sleep(1000);
				//	System.out.println("Waiting for element visibility");
				//	WebDriverWait wait = new WebDriverWait(d, 15);
				//	wait.until(ExpectedConditions.visibilityOf(j));
			//	} //catch (Exception e) {
					// TODO Auto-generated catch block
				//	e.printStackTrace();
				//}

		
			
			

}
